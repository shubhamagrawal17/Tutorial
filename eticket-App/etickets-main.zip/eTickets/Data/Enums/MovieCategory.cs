﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data
{
    public enum MovieCategory
    {
        Aksiyon = 1,
        Komedi,
        Drama,
        Belgesel,
        Animasyon,
        Korku
    }
}
